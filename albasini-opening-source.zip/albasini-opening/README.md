# Prototype complet — Bijouterie Albasini

Ouvrir `index.html` dans un navigateur récent. Le prototype fonctionne sans installation ni dépendance. `Albasini-prototype-autonome.html` contient les images et peut être ouvert seul.

## Parcours

- L’ouverture conserve la loupe joaillière, déclenchée sur la bague; sur mobile, toucher le bijou l’active.
- Le bandeau d’ouverture affiche le logo officiel de la boutique.
- La section collections devient une galerie horizontale pilotée par le défilement sur grand écran. Sur mobile et avec le mouvement réduit, les deux collections restent présentées à la suite.
- Dans l’atelier, un tracé SVG relie les trois gestes : sa ligne repère reste visible, puis le tracé foncé progresse au défilement.
- Les marques se révèlent en séquence typographique. La barre supérieure suit la progression dans toute la page.
- La navigation, les coordonnées, les horaires, l’itinéraire et le formulaire restent accessibles sans parcourir les animations.

## Contenu et limites

Le logo, les informations de boutique et les marques sont repris du site actuel. Les trois photos sont des visuels générés pour la maquette, signalés comme non contractuels. L’illustration du cadran est un dessin original sans marque ni modèle représenté.

Le formulaire prépare un courriel dans la messagerie de la personne qui le remplit; il n’envoie ni ne stocke les données sur un serveur. L’adresse de destination, trouvée dans des annuaires publics, reste à confirmer avec la boutique avant toute mise en ligne. Les mentions légales renvoient au site actuel.

Cette maquette est un prototype local : elle n’est pas publiée et n’est pas connectée au site actuel.
